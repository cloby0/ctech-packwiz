
                                                                    
                       _____ _____ _____ _____ _____ _____ _____  ______
                      |   __| __  |     |   __|  _  |     |_   _||_    _|
                      |   __|    -|  |  |  |  |   __|  |  | | |   _|  |_
                      |__|__|__|__|_____|_____|__|__|_____|_|_|_ |      |
                      |   __|_   _|  |  |    \|     |     |   __||      |
                      |__   | | | |  |  |  |  |-   -|  |  |__   ||      |
                      |_____| |_| |_____|____/|_____|_____|_____||______|
					  
			  • ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ •
                                                                    
		  |	CurseForge: https://www.curseforge.com/members/frogpotstudios/projects
		  
									 📌 Naming rules 📌
		      • ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ •
				| In order to change the camera's design, you must use an anvil
				| to change its name according to what design you want.
				| NOTE: Names are NOT case-sensitive.
			  
			  | Default Camera
			  - White -> NO CHANGE, THIS IS THE DEFAULT LOOK
			  - Black -> "camera black" or "black camera"
			  - Red -> "camera red" or "red camera"
			  - Yellow -> "camera yellow" or "yellow camera"
			  - Green -> "camera green" or "green camera"
			  - Blue -> "camera blue" or "blue camera"
			  
			  | Polaroid Camera
			  - Default -> "polaroid camera" or "camera polaroid"
			  - White -> "white polaroid camera" or "polaroid camera white" or "white camera polaroid" or "camera polaroid white"
			  - Black -> "black polaroid camera" or "polaroid camera black" or "black camera polaroid" or "camera polaroid black"
			  - Red -> "red polaroid camera" or "polaroid camera red" or "red camera polaroid" or "camera polaroid red"
			  - Yellow -> "yellow polaroid camera" or "polaroid camera yellow" or "yellow camera polaroid" or "camera polaroid yellow"
			  - Green -> "green polaroid camera" or "polaroid camera green" or "green camera polaroid" or "camera polaroid green"
			  - Blue -> "blue polaroid camera" or "polaroid camera blue" or "blue camera polaroid" or "camera polaroid blue"
			  
			  | Modern Camera
			  - Default -> "modern camera" or "camera modern"
			  
			  | Box Camera
			  - Default -> "box camera" or "camera box"
			  
			    | Don't like one part of the pack? You can revert the camera and album back to their
				| original item models using the namings below.
			  
			  | Old Camera or Photo Album
			  - Camera -> "Old Camera" or "Camera Old"
			  - Album -> "Old Album" or "Album Old"
		  
		      • ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ •
			  
				| README is a work in progress.
				| More socials coming soon!

			  • ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ •